package org.pngquant;

public class PngQuantException extends Exception {
}
